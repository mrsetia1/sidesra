<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-3 mt-4">
            
        <form action="<?php echo e(route('save-category')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="category_title">Nama kategori</label>
                <input name="category_title" type="title" class="form-control" id="category_title" aria-describedby="titleHelp" placeholder="Nama kategori">
            </div>
            <div class="form-group">
                <label for="category_color">Warna</label>
                <input name="category_color" type="color" class="form-control" id="category_color" placeholder="Warna">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>

        </div>
    </div>
    <hr>
    
    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
      <button type="button" class="close" data-dismiss="alert">×</button> 
      <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mt-2 mb-2">
            <div class="card">
                <div class="card-body">
                    <?php echo e($category->title); ?>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sidesraapi\resources\views/categories/index.blade.php ENDPATH**/ ?>