    <?php $__env->startSection('content'); ?>
    
    <div class="row mt-4">
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-2">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($comment->author->name); ?></h5>
                    <p class="card-text">
                        <?php echo e($comment->content); ?>

                    </p>
                    <a href="<?php echo e($comment->post->link()); ?>" class="btn btn-primary">Lihat postingan >>></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-md-12">
        <?php echo e($comments->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sidesraapi\resources\views/comments/index.blade.php ENDPATH**/ ?>