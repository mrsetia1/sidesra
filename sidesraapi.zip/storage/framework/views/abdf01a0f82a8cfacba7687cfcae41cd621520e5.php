
<?php echo e($category->title); ?>

<?php /**PATH C:\xampp\htdocs\laravel\sidesraapi\resources\views/categories/category.blade.php ENDPATH**/ ?>