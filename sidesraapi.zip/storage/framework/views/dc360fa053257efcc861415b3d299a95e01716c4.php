    <?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-3 mt-4">
            
        <form action="<?php echo e(route('save-tag')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="tag_title">Nama tag</label>
                <input name="tag_title" type="text" class="form-control" id="tag_title" aria-describedby="titleHelp" placeholder="Nama kategori">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>

        </div>
    </div>
    <hr>
    
    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
      <button type="button" class="close" data-dismiss="alert">×</button> 
      <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="row">
        <div class="bd-example">
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#" class="badge badge-pill badge-primary"> <?php echo e($tag->title); ?> </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sidesraapi\resources\views/tags/index.blade.php ENDPATH**/ ?>