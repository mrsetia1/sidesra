<?php
return[
    'title' => 'DESAKU | KERTAJAYA',
    'favicon' => 'avilon/img/favicon.png',
    'title_header' => 'KERTAJAYA',
    'logo_url' => 'avilon/img/logo.png',
    'image_banner_url' => 'avilon/img/banner1.jpg',
    'welcome_message' => 'SELAMAT DATANG DI DESAKU KERTAJAYA',
    'welcome_message_sub' => 'Desaku adalah Sistem Informasi Desa dari Desa Kertajaya Untuk Warga Kertajaya',
    'welcome_message_button_text' => 'JELAJAHI',
    'welcome_message_button_url' => '/jelajah',

    'telepon' => '085622',
    'email' => 'kertajaya@gmail.com',
    'jalan' => 'Kertajaya No. 2',
    'desa' => 'Kertajaya',
    'kecamatan' => 'Cibatu',
    'kabupaten' => 'Garut',
    'propinsi' => 'Jawa Barat',
    'kodepos' => '45656',
    'url_facebook' => 'KERTAJAYA',
    'url_instagram' => 'KERTAJAYA',

];